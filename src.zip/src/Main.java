import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class Main {
    private static final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/";
    private static final String DATABASE_NAME = "minions_db";
    private static Connection connection;
    private static String query;
    private static PreparedStatement statement;

    private static BufferedReader read;

    public static void main(String[] args) throws SQLException, IOException {

        read = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Please enter your username for MySQL driver : ");
        String username = read.readLine();
        System.out.println();
        System.out.println("Please enter your password for MySQL driver : ");
        String password = read.readLine();
        System.out.println();

        Properties properties = new Properties();
        properties.setProperty("user", username);
        properties.setProperty("password",password);

        connection = DriverManager.getConnection(CONNECTION_STRING + DATABASE_NAME, properties);




        System.out.println("Please enter numbers from 1 to 9, or any other number for exit");
        int numb = Integer.parseInt(read.readLine());
        while (numb >= 1 && numb <= 9){
            switch (numb){
                case 1:
                    System.out.println("The database was well understood and I am familiar with it!");
                    break;
                case 2:
                    //2. Get Villains’ Names
                    getVillainsNamesAndCountOfMinions();
                    break;
                case 3:
                    // 3.Get Minion Names
                    getMinionNames();
                    break;
                case 4:
                    //4.Add Minion
                    addMinionEx();
                    break;
                case 5:
                    //5. Change Town Names Casing
                    changeTownNamesCasingEx5();
                    break;
                case 6:
                    //6. Remove Villain
                    removeVillain();
                    break;
                case 7:
                    //7.Print All Minion Names
                    printAllMinionNamesEx7();
                    break;
                case 8:
                    //8.Increase Minions Age
                    increaseMinionsAge();
                    break;
                case 9:
                    //9.Increase Age Stored Procedure
                    increaseAgeWhitStoredProcedure();
                    break;

            }
            System.out.println("Please enter numbers from 1 to 9, or any other number for exit");
            numb = Integer.parseInt(read.readLine());
        }

    }

    private static void removeVillain() throws IOException, SQLException {
        System.out.println("Please enter the id of Villain :");
        int numb = Integer.parseInt(read.readLine());
        query = "SELECT a.name , count(c.id) AS 'count'\n" +
                "FROM villains AS a\n" +
                "JOIN minions_villains AS b\n" +
                "ON a.id = b.villain_id\n" +
                "JOIN minions AS c\n" +
                "ON b.minion_id = c.id\n" +
                "GROUP BY a.id\n" +
                "HAVING a.id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1, numb);
        ResultSet rs = statement.executeQuery();
        while (rs.next()){
            System.out.println(String.format("%s was deleted\n" +
                    "%d minions released\n", rs.getString("name"), rs.getInt("count")));
        }

        query = "DELETE FROM minions_villains\n" +
                "WHERE villain_id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1, numb);
        statement.execute();
        query = "DELETE FROM villains\n" +
                "WHERE id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1, numb);
        statement.execute();

    }

    private static void increaseMinionsAge() throws IOException, SQLException {
        System.out.println("Enter the IDs of minions on row separated by space: ");
        int[] idMinions = Arrays.stream(read.readLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();
        for (int i = 0; i <idMinions.length ; i++) {
            query = "UPDATE minions SET name = LOWER(name)  WHERE id = ?";
            statement = connection.prepareStatement(query) ;
            statement.setInt(1,idMinions[i]);
            statement.execute();
            query = "UPDATE minions SET age = age + 1 WHERE id = ?";
            statement = connection.prepareStatement(query) ;
            statement.setInt(1,idMinions[i]);
            statement.execute();
        }
        query = "SELECT name, age FROM minions";
        statement = connection.prepareStatement(query);
        ResultSet rs = statement.executeQuery();
        while (rs.next()){
            System.out.println(String.format("%s %d", rs.getString("name"), rs.getInt("age")));
        }

    }

    private static void printAllMinionNamesEx7() throws SQLException {
        query ="SELECT name FROM minions";
        statement = connection.prepareStatement(query);
        ResultSet rs = statement.executeQuery();
        List<String> minionsInList = new ArrayList<>();
        while (rs.next()){
            minionsInList.add(rs.getString("name"));
        }
        for (int i = 0; i < minionsInList.size()/2; i++) {
            System.out.println(minionsInList.get(i));
            System.out.println(minionsInList.get(minionsInList.size() - 1 - i));
        }
    }

    private static void changeTownNamesCasingEx5() throws IOException, SQLException {
        System.out.println("Enter name of the country: ");
        String countryName = read.readLine();
        query = "UPDATE towns SET name = UPPER(name) WHERE country = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1,countryName);
        int countTownsAffected = statement.executeUpdate();
        System.out.println(String.format("%d town names were affected. ", countTownsAffected));
        query = "SELECT name FROM towns WHERE country = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1,countryName);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()){

            System.out.printf("[%s, ", resultSet.getString("name"));
            while(resultSet.next()) {
                if (!resultSet.isLast()){
                    System.out.printf("%s, ", resultSet.getString("name"));
                }else{
                    System.out.printf("%s]", resultSet.getString("name"));
                }

            }

        }else{
            System.out.println("No town names were affected.");
        }




    }

    private static void increaseAgeWhitStoredProcedure() throws IOException, SQLException {
        System.out.println("Please write the following text in the console using Database minions_db" +
                " and execute (if you have already please disregard) : ");
        System.out.println("create procedure usp_get_older(minion_id int)\n" +
                "BEGIN\n" +
                "    UPDATE minions\n" +
                "    SET age = age + 1\n" +
                "    WHERE id = minion_id;\n" +
                "END;");


        System.out.println("Enter minion id : ");
        int minionId = Integer.parseInt(read.readLine());
        query = "CALL usp_get_older(?)";
        CallableStatement callableStatement = connection.prepareCall(query);
        callableStatement.setInt(1, minionId);
        callableStatement.execute();
        query = "SELECT name, age FROM minions WHERE id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1,minionId);
        ResultSet rs = statement.executeQuery();
        while (rs.next()){
            System.out.println(String.format("%s %d", rs.getString("name"), rs.getInt("age")));
        }
    }

    private static void addMinionEx() throws IOException, SQLException {
        System.out.println("Enter minion parameters: name, age, town name ");
        String[] minionParameters = read.readLine().split("\\s+");
        String minionName = minionParameters[0];
        int minionAge = Integer.parseInt(minionParameters[1]);
        String minionTown = minionParameters[2];
        System.out.println("Enter villain name: ");
        String villainName = read.readLine();

        if (!checkEntityExistsByName(minionTown, "towns")){
            insertEntityInTown(minionTown);
            System.out.println(String.format("Town %s was added to the database.", minionTown));
        }
        if (!checkEntityExistsByName(villainName,"villains")){
            insertEntityInVillains(villainName);
            System.out.printf("Villain %s was added to the database.%n", villainName);
        }
        if (!checkEntityExistsByName(minionName,"minions")){
            insertMinionInMinions(minionName,minionAge);
            System.out.println();
        }
        newMinionServantVillain(villainName,minionName);
        System.out.printf("Successfully added %s to be minion of %s.", minionName, villainName);


    }

    private static void newMinionServantVillain(String villainName, String minionName) throws SQLException {
        query = "UPDATE minions_villains AS b" +
                " JOIN villains AS a ON b.villain_id = a.id " +
                "JOIN minions AS c ON b.minion_id = c.id " +
                "SET b.villain_id = a.id AND b.minion_id = c.id " +
                "WHERE a.name = ? and c.name = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1,villainName);
        statement.setString(2,minionName);
        statement.execute();

    }


    private static void insertMinionInMinions(String minionName, int minionAge) throws SQLException {
        query = "INSERT INTO minions (name,age) value(?, ?)";
        statement = connection.prepareStatement(query);
        statement.setString(1,minionName);
        statement.setInt(2,minionAge);
        statement.execute();
    }

    private static void insertEntityInVillains(String villainName) throws SQLException {
        query = "INSERT INTO villains (name,evilness_factor) value(?, ?)";
        statement = connection.prepareStatement(query);
        statement.setString(1,villainName);
        statement.setString(2,"evil");
        statement.execute();
    }

    private static void insertEntityInTown(String minionTown) throws SQLException {
        query = "INSERT INTO towns (name,country) value(?, ?)";
        statement = connection.prepareStatement(query);
        statement.setString(1,minionTown);
        statement.setString(2,"NULL");
        statement.execute();
    }

    private static boolean checkEntityExistsByName(String entityName, String tableName) throws SQLException {
        query = "SELECT * FROM " + tableName + " WHERE name = ?";
        statement = connection.prepareStatement(query);
        statement.setString(1,entityName);
        ResultSet resultSet = statement.executeQuery();

        return resultSet.next();
    }

    private static void getMinionNames() throws IOException, SQLException {
        System.out.println("Enter villain id: ");
        int villian_id = Integer.parseInt(read.readLine());
        if (!checkEntityExists(villian_id, "minions_db.villains")){
            System.out.printf("No villain with id %d exists in the database.", villian_id);
            return;
        }
        System.out.printf("Villain: %s%n", getEntityNameById(villian_id, "minions_db.villains"));
        getMinionsAndAgeByVillainId(villian_id);
    }

    private static void getMinionsAndAgeByVillainId(int villian_id) throws SQLException {
        query ="SELECT m.name, m.age FROM minions AS m\n" +
                " JOIN minions_villains mv on m.id = mv.minion_id\n" +
                " WHERE mv.villain_id = ?";
        statement = connection.prepareStatement(query);
        statement.setInt(1, villian_id);
        ResultSet resultSet = statement.executeQuery();
        int minionNumber = 0;

        while (resultSet.next()){
            System.out.printf("%d. %s %d%n", ++minionNumber, resultSet.getString("name"), resultSet.getInt(2));
        }
    }

    private static String getEntityNameById(int entityId, String tableName) throws SQLException {
        query = "SELECT name FROM " + tableName + " WHERE id =?";
        statement = connection.prepareStatement(query);
        statement.setInt(1,entityId);



        ResultSet resultSet =  statement.executeQuery();
        return resultSet.next() ? resultSet.getString("name") : null;

    }

    private static boolean checkEntityExists(int villian_id, String villains) throws SQLException {
       query =  "SELECT * FROM " + villains + " WHERE minions_db.villains.id = ?";
       statement = connection.prepareStatement(query);
       statement.setInt(1,villian_id);
       ResultSet resultSet = statement.executeQuery();
       return resultSet.next();

    }

    private static void getVillainsNamesAndCountOfMinions() throws SQLException {
        query = "SELECT v.name, COUNT(mv.minion_id) AS count\n" +
                "FROM minions_db.villains AS v\n" +
                "JOIN minions_db.minions_villains AS mv ON v.id = mv.villain_id\n" +
                "GROUP BY v.name\n" +
                "HAVING count > 15\n" +
                "ORDER BY `count` DESC";

        statement = connection.prepareStatement(query);
        ResultSet resultSet = statement.executeQuery();

        while (resultSet.next()){
            System.out.printf("%s %d%n", resultSet.getString(1),
                    resultSet.getInt(2));
        }

    }
}
